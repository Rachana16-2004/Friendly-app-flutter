import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:app/pages/feed_page.dart'; // Update to your project structure



class AuthPage extends StatefulWidget {
  @override
  _AuthPageState createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool isSignUp = false;
  bool isLoading = false;

  void _toggleForm() {
    setState(() {
      isSignUp = !isSignUp;
    });
  }

  Future<void> _submit() async {
    final supabase = Supabase.instance.client;
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter both email and password.')),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      final response = isSignUp
          ? await supabase.auth.signUp(email: email, password: password)
          : await supabase.auth.signInWithPassword(email: email, password: password);

      final user = response.user;

      if (user != null) {
        print('✅ Auth successful for user ID: ${user.id}');

        if (isSignUp) {
          // ⬇️ INSERT into users table
          final insertResponse = await supabase.from('users').insert({
            'id': user.id,
            'email': email,
          });

          print('🗃️ User inserted into users table: $insertResponse');
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => FeedPage()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Check your email to confirm your account.'),
        ));
      }
    } on AuthException catch (e) {
      print('❌ AuthException: ${e.message}');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('❌ ${e.message}'),
      ));
    } catch (e) {
      print('❌ Unknown error: $e');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('❌ Unexpected error occurred.'),
      ));
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isSignUp ? 'Sign Up' : 'Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 10),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _submit,
                    child: Text(isSignUp ? 'Sign Up' : 'Sign In'),
                  ),
            TextButton(
              onPressed: _toggleForm,
              child: Text(
                isSignUp
                    ? 'Already have an account? Sign In'
                    : 'Don’t have an account? Sign Up',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
