import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'create_post_page.dart';


class FeedPage extends StatefulWidget {
  @override
  _FeedPageState createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  List<dynamic> posts = [];

  @override
  void initState() {
    super.initState();
    fetchPosts();
  }

  Future<void> fetchPosts() async {
    final response = await Supabase.instance.client
        .from('posts')
        .select()
        .order('created_at', ascending: false);
    setState(() {
      posts = response;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Friends Feed"), actions: [
        IconButton(
          icon: Icon(Icons.add),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CreatePostPage())),
        )
      ]),
      body: RefreshIndicator(
        onRefresh: fetchPosts,
        child: ListView.builder(
          itemCount: posts.length,
          itemBuilder: (context, index) {
            final post = posts[index];
            return Card(
              margin: EdgeInsets.all(10),
              child: Column(
                children: [
                  if (post['image_url'] != null)
                    Image.network(post['image_url']),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(post['status_text'] ?? ''),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}