import 'package:flutter/material.dart';

class CommentsPage extends StatelessWidget {
  final String postId;
  CommentsPage({required this.postId});

  @override
  Widget build(BuildContext context) {
    // Placeholder UI
    return Scaffold(
      appBar: AppBar(title: Text('Comments')),
      body: Center(child: Text('Comments for post $postId')),
    );
  }
}