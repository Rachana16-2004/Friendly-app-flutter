import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart'; // for kIsWeb
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as path;

class CreatePostPage extends StatefulWidget {
  @override
  _CreatePostPageState createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final TextEditingController _textController = TextEditingController();
  XFile? _image;
  Uint8List? _imageBytes;
  String? _imageName;

  Future<void> pickImage() async {
    final ImagePicker picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      final bytes = await picked.readAsBytes();
      setState(() {
        _image = picked;
        _imageBytes = bytes;
        _imageName = picked.name;
      });
    }
  }

  Future<void> uploadPost() async {
    final supabase = Supabase.instance.client;
    String? imageUrl;

    if (_imageBytes != null && _imageName != null) {
      final fileExt = path.extension(_imageName!);
      final fileName = "${Uuid().v4()}$fileExt";
      final filePath = "posts/$fileName";

      await supabase.storage
          .from('post-images')
          .uploadBinary(filePath, _imageBytes!);

      imageUrl = supabase.storage.from('post-images').getPublicUrl(filePath);
    }

    await supabase.from('posts').insert({
      'user_id': supabase.auth.currentUser!.id,
      'status_text': _textController.text,
      'image_url': imageUrl,
    });

    Navigator.pop(context); // ✅ Now correctly references Flutter's BuildContext
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Post")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _textController,
                decoration: InputDecoration(labelText: "What's on your mind?"),
              ),
              SizedBox(height: 10),
              if (_imageBytes != null)
                kIsWeb
                    ? Image.memory(_imageBytes!) // ✅ Web support
                    : Image.file(File(_image!.path)), // ✅ Mobile/desktop
              TextButton.icon(
                onPressed: pickImage,
                icon: Icon(Icons.image),
                label: Text("Pick Image"),
              ),
              SizedBox(height: 10),
              ElevatedButton(onPressed: uploadPost, child: Text("Post")),
            ],
          ),
        ),
      ),
    );
  }
}
