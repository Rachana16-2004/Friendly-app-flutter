import 'package:flutter/material.dart';
import '../pages/comments_page.dart';
import '../pages/edit_post_page.dart';

class PostCard extends StatelessWidget {
  final Map post;
  const PostCard({required this.post});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (post['image_url'] != null) Image.network(post['image_url']),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(post['status_text'] ?? ''),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                icon: Icon(Icons.comment),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => CommentsPage(postId: post['id'])),
                ),
              ),
              IconButton(
                icon: Icon(Icons.edit),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => EditPostPage(post: post)),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}